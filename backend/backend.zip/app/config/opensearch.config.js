module.exports = Object.freeze({
  HOST: 'search-lrc-poc-public-3hvhhuoswijfyaz5agur6yustq.ca-central-1.es.amazonaws.com',
  PROTOCOL: 'https',
  PORT: '443',
  AUTH: 'lrcadmin:LrcPoc999!'
})
